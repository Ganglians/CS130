To run the program just type "./a.out samplemeshes/[filename].txt" and it'll render the mesh of that file.

It'll begin by rendering the top view of the mesh as that's the default view and when you perform loop subdivision it'll revert back to the top view of the mesh.

You simply need to perform a mouse click in order to do loop subdivision. Pressing '1', '2', or '3' will switch the view of the mesh from top, side, or front.
